Read Me 

How to use Scribble revision helper chatbot.

1. Dowload the zip file conatining all the contents of the web application.

2. Vs Code - application used to develop and run

3. To run the project, please locate the Chat.py file and press the run icon

4. Flask should then run its server and provide a dedicated link located within the Vs codes terminal 

5. The link should look something like (http://127.0.0.1:5001/home), copy and paste this address to a browser such as chrome.

6. From then on the web app should be up ad running and should be ready for use.
