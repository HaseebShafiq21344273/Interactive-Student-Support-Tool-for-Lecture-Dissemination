from flask import Flask, request, jsonify, render_template #import flask libraries
from flask_cors import CORS #for requests across origins
import anthropic # for claude chatbot model
from youtube_transcript_api import YouTubeTranscriptApi #transcript
import os
from dotenv import load_dotenv #used for api key (not working)

load_dotenv()

app = Flask(__name__, static_folder='static')
CORS(app)  

client = anthropic.Anthropic( #api key for custom model
    api_key="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"
)

@app.route('/')
@app.route('/home')     #diff routes to render pages
def index():
    return render_template('ChatBotTutor.html')

@app.route('/about')
def about():
    return render_template('AboutUs.html')

@app.route('/contact')
def contact():
    return render_template('Contact.html')

def extract_youtube_transcript(url):
    try:
        video_id=url.replace('https://www.youtube.com/watch?v=', '') #get youtube link
        transcript = YouTubeTranscriptApi.get_transcript(video_id)  #get youtube transcript

        output=''
        for x in transcript:
            sentance = x['text']    #format traanscript into string
            output += f'{sentance}\n'

        return output
    except Exception as e:
        print(f"Error with exraction: {str(e)}") #error handling
        return None

        

@app.route('/api/summarise', methods=['POST']) #post request to endpoint
def summarize_video():
    try:
        data = request.json
        video_link = data.get('video_link', '') #gets video link
        
        if not video_link:
            return jsonify({"error": "No video link provided"}), 400 #error if an invalid link entered
        transcript = extract_youtube_transcript(video_link)

        if not transcript:
            return jsonify({"Error: no link provided"}),400 #error if there is not available transcript 
            
        prompt_ai="""You are an AI assistant specialized in creating educational summaries and revision materials. Your task is to analyze a video transcript, summarize its content, and create comprehensive study aids for students. Additionally, you should be prepared to answer any questions about the summary you provide.\n\nHere is the video transcript you need to analyze:\n\n<video_transcript>\n{{VIDEO_TRANSCRIPT}}\n</video_transcript>\n\nPlease follow these steps to complete your task:\n\n1. Carefully read and analyze the video transcript.\n2. Create a concise summary and revision materials based on the content.\n3. Format your output as specified below.\n4. Prepare to answer potential questions about your summary and materials.\n\nBefore providing your final output, show your thought process and preparation inside <preparation> tags. Be thorough in this section, as it will form the basis for your summary and revision materials. Include the following:\n\na. Identify and list main topics\nb. Extract key quotes for each topic\nc. Note any visual elements mentioned\nd. List potential key terms and concepts\ne. Outline the video's structure\nf. Formulate potential review questions\n\nAfter your preparation, present your summary and revision materials in the following format:\n\n<summary>\n[Concise summary of the video content, approximately 10-15% of the original transcript length]\n</summary>\n\n<revision_materials>\n<key_terms>\n[List of 5-10 key terms or concepts with their definitions]\n</key_terms>\n\n<main_takeaways>\n[List of 3-5 main takeaways or learning objectives]\n</main_takeaways>\n\n<review_questions>\n[5-10 review questions (multiple-choice or short answer) with answers]\n</review_questions>\n\n<content_outline>\n[Brief outline of the video's structure and content flow]\n</content_outline>\n\n<full_summary>\n[Detailed summary of the video's content]\n</full_summary>\n</revision_materials>\n\nRemember to:\n- Use clear, concise language appropriate for students.\n- Focus on the most important and relevant information.\n- Mention any crucial visual elements from the video.\n- Provide brief explanations for technical terms or complex concepts.\n- Ensure your summary and materials are comprehensive yet easy to understand.\n\nAfter completing the summary and revision materials, be prepared to answer any questions about the content you've presented."""
        prompt =prompt_ai.replace("{VIDEO_TRANSCRIPT}", transcript)
        message = client.messages.create(
            model="claude-3-7-sonnet-20250219", #best performance model for long prompt
            max_tokens=4000,
            temperature=0.7,  
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                        "type": "text",
                        "text": prompt 
                }
                    ]
                }
            ]
        )   
        return jsonify({"response": message.content[0].text}) #json ai responce
        
    except Exception as api_error:
            print(f"API error: {str(api_error)}")
            return jsonify({"error": f"API error: {str(api_error)}"}), 500 #errors

@app.route('/api/chat',methods=['POST']) #post req
def message_chatbot():
        try:
            data= request.json
            userMessage=data.get('message', '') #get users submitted message
            context=data.get('context', {}) #uses summary as context

            if not userMessage:
                return jsonify({"error": "No Message"}), 400 #message error
            messengerPrompt = """You are a helpful AI assistant that helps students understand educational content. You have access to a summary of a video that the student watched. Use this information to provide helpful, accurate answers. Keep your responses concise, in sentences or paragraphs no bullet points so it is clear and focused on the student's question. Here is the summary information about the video:"""

            if context.get('summary'):
                messengerPrompt +=f"\n\n SUMMARY:\n{context['summary']}" #contect info for bot

            if context.get('keyTerms'):
                messengerPrompt +=f"\n\n Keyterms:\n{context['keyTerms']}"

            if context.get('mainTakeaways'):
                messengerPrompt  +=f"\n\n MainTakeaways:\n{context['mainTakeaways']}"

            message = client.messages.create(
            model="claude-3-haiku-20240307", #faster model for quick responces
            max_tokens=1000,
            temperature=0.7,  
            system=messengerPrompt,
            messages=[
                {           
                        "role": "user",
                        "content": userMessage
                }
            ]
        )
            return jsonify({"response": message.content[0].text}) #ai responce
        
        except Exception as api_error:
            print(f"API error: {str(api_error)}")
            return jsonify({"error": f"API error: {str(api_error)}"}), 500
        

if __name__ == '__main__': #start flask server
    app.run(debug=True, port=5001)

            
