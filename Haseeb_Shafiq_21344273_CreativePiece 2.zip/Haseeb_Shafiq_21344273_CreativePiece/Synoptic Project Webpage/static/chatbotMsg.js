document.addEventListener('DOMContentLoaded',function() { //initialise 
    const chatMsgInput= document.querySelector('.chatInput textarea');
    const chatbox = document.querySelector('.chatBox')
    const chatSubmit = document.getElementById('sendBtn');
    
    function formatResponse(response){      //formating ai response
        if (!response) return 'Content not available';

        return response
            .replace(/\n\n/g, '<br><br>')
            .replace(/\n/g, '<br>')
            .replace(/^\d+\.\s+(.*?)$/gm, '<li>$1</li>')  
            .replace(/^[\-\*]\s+(.*?)$/gm, '<li>$1</li>');
    }

    function addMessage(message, isOutgoing = false, formatted = false){ //add msg to chat
        const li =document.createElement('li');
        li.className = isOutgoing ? 'outgoingChat chat': 'incomingChat chat'; //class dependant on if its ai or user message
        const p = document.createElement('p');
       if(formatted){
        p.innerHTML=message; //for ai
       }
       else{
        p.textContent = message; //for user
       }

        li.appendChild(p); 
        chatbox.appendChild(li);
        chatbox.scrollTop=chatbox.scrollHeight; //scroll down to bottom
    }

    async function sendMessage(message){ //post request user msg
        try{
        const videoSummary = document.getElementById('summary').textContent; //get content from these sections
        const videoKeyTerms = document.getElementById('keyTerms').textContent;
        const videoMainTakeaway = document.getElementById('mainTakeaways').textContent;

        const response = await fetch('/api/chat', { //post req to ai 
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                message: message,
                context:{ summary:videoSummary,keyTerms:videoKeyTerms,mainTakeaways:videoMainTakeaway} //sends the video context and msg to bot
                
            })
        });

        if (!response.ok) {
            throw new Error('Error with request'); //error handling
        }

        const data = await response.json();
        const formattedResponse= formatResponse(data.response) //format response
        addMessage(formattedResponse, false, true); //ai response added
    }
        catch(error){
            console.error('Error', error);
            alert('An error occured:' + error.message); //error handling
        }
    }
    chatSubmit.addEventListener('click', function(){ //submit btn to send user msg
        const message = chatMsgInput.value.trim();
        if(message){
            addMessage(message, true);

            chatMsgInput.value = '';

            sendMessage(message);
        }
    });
})