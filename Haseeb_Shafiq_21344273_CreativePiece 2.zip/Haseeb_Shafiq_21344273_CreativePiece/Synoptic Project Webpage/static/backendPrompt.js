let popup = null; //global

function openPopup(){
    popup.classList.add("open-popup")       //functions to open and close popups
}

function closePopup(){
    popup.classList.remove("open-popup")
}

document.addEventListener('DOMContentLoaded',function() {       //initialise variables
    const videoForm= document.getElementById('videoForm');
    const videoContainer = document.querySelector('.video-Container')
    const submitBtn = document.getElementById('submitBtn');
    const loadingMessage = document.getElementById('loadingMessage');
    const resultContainer = document.getElementById('resultContainer');

    const summaryElement= document.getElementById('summary');               //getting our ref points to place info we get
    const keyTermsElement = document.getElementById('keyTerms');
    const mainTakeawaysElement = document.getElementById('mainTakeaways');
    const reviewQuestionsElement = document.getElementById('reviewQuestions');
    const contentOutlineElement = document.getElementById('contentOutline')
    popup = document.getElementById("popUp");

    videoForm.addEventListener('submit', async function (e) {       //validation for entering link
        e.preventDefault();
        
        const videoLink = document.getElementById('videoLink').value.trim(); //trim any whitespace

        if (!videoLink){
            alert('Enter a valid link');
        return;
    }

    if(videoContainer){
        videoContainer.innerHTML=''; //clear video
    

    embedVideoLink= videoLink.replace('/watch?v=', '/embed/'); //convert link with embed 
    const iframe = document.createElement("iframe");
    iframe.src=embedVideoLink;                      //place in new link to work with iframe
    videoContainer.appendChild(iframe);             //add in iframe
    }

    
    submitBtn.disabled=true; //prevent submission once already pressed
    loadingMessage.style.display ='flex';
    resultContainer.style.display='none';

   setTimeout(() => {
    loadingMessage.scrollIntoView({ behavior: 'smooth' }); //scroll to loading message
}, 100);

    try{
        const response = await fetch('/api/summarise', {            //api request to claude model
            method: 'POST',
            headers: {'Content-Type': 'application/json'},          //post request to apis endpoint
            body: JSON.stringify({video_link: videoLink})
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error('Error with request'); //error handling
        }
        
        function getSection(text, sectionName) { //extracting content by looking for sections name tags
            const pattern = `<${sectionName}>[\\s\\S]*?</${sectionName}>`; 
            const match = text.match(new RegExp(pattern, 'i'));     //search for content matching pattern
            
            if (match) {
                
                const content = match[0].replace(`<${sectionName}>`, '').replace(`</${sectionName}>`, ''); //extract content between tags and remove tags
                return content.trim();
            }
            
            return null;
        }
        
        function formatContent(content){
            if (!content) return 'Content not available';

            return content
                .replace(/\n\n/g, '<br><br>') //formatting to html elements
                .replace(/\n/g, '<br>')
                .replace(/^\d+\.\s+(.*?)$/gm, '<li>$1</li>')  
                .replace(/^[\-\*]\s+(.*?)$/gm, '<li>$1</li>');
        }

        summaryElement.innerHTML=formatContent(getSection(data.response,'summary'))     //display results with formatting
        keyTermsElement.innerHTML=formatContent(getSection(data.response,'key_terms'))
        mainTakeawaysElement.innerHTML=formatContent(getSection(data.response,'main_takeaways'))
        reviewQuestionsElement.innerHTML=formatContent(getSection(data.response,'review_questions'))
        contentOutlineElement.innerHTML=formatContent(getSection(data.response,'content_outline'))

        
        openSection('summary');
        resultContainer.style.display='block';
        resultContainer.scrollIntoView({behavior: 'smooth'});
        
        }catch (error){
            console.error('Error', error);
            alert('An error occured:' + error.message);     //error handling for api requests
        } finally{
            loadingMessage.style.display='none';
            submitBtn.disabled=false;
        }
    
    });
});
function openSection(contentName){ //function for tab navigation 
    var i;
    var x = document.getElementsByClassName("tab-content");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";  
      }
      document.getElementById(contentName).style.display ="block";
}
